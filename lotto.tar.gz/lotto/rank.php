<?php
// ȸ����ȣ
$drwNo = $_GET['drwNo'];
if(!$drwNo) $drwNo=1;

// ������� ����
$db = new SQLite3('lotto.sqlite3', SQLITE3_OPEN_CREATE | SQLITE3_OPEN_READWRITE);

// ����� ���� ������ 
$sql = "SELECT drwNo FROM rnk WHERE drwNo=$drwNo LIMIT 0,1";
echo $sql.'<Br>';
$result = $db->query($sql) or die($_SERVER['PHP_SELF'].' line '.__LINE__.', SQL : '.$sql);
$row = $result->fetchArray(SQLITE3_ASSOC);
//print_r($row);
//exit;
if($row){ //ó�� ����
	// ��������
	echo '{drwNo:'.$drwNo.',msg:"����"}';
	// �������
	$db->close();
	exit;
}


// ����ȸ���� ������ȣ ��÷ ���
$sql="
insert into rnk(drwNo, have, rnk)
select e.drwNo as drwNo
     , c.no as haveNo
     , case d.cnt when 3 then 5
                  when 4 then 4
                  when 5 then case e.bnusNo when c.drwtNo1 then 2
                                            when c.drwtNo2 then 2
                                            when c.drwtNo3 then 2
                                            when c.drwtNo4 then 2
                                            when c.drwtNo5 then 2
                                            when c.drwtNo6 then 2
                              else 3 end
                  when 6 then 1 end as rank
  from have c
     , (
        select no, cnt
          from (
                select a.no, count(a.no) as cnt
                  from have a
                     , (select drwtNo1 as drwtNo from history where drwNo=$drwNo
                        union all
                        select drwtNo2 as drwtNo from history where drwNo=$drwNo
                        union all
                        select drwtNo3 as drwtNo from history where drwNo=$drwNo
                        union all
                        select drwtNo4 as drwtNo from history where drwNo=$drwNo
                        union all
                        select drwtNo5 as drwtNo from history where drwNo=$drwNo
                        union all
                        select drwtNo6 as drwtNo from history where drwNo=$drwNo) b
                 where a.use=1
                   and (a.drwtNo1 = b.drwtNo
                        or a.drwtNo2 = b.drwtNo
                        or a.drwtNo3 = b.drwtNo
                        or a.drwtNo4 = b.drwtNo
                        or a.drwtNo5 = b.drwtNo
                        or a.drwtNo6 = b.drwtNo)
                 group by a.no
                 order by a.no asc
               )
         where cnt>2
       ) d
     , (select drwNo, bnusNo from history where drwNo=$drwNo) e
 where c.no=d.no
";

$db->busyTimeout(1000);
$resultInsert = $db->exec($sql) or die($PHP_SELF.' line '.__LINE__.', SQL : '.$sql);
#$json_data = array();
#// ������ ����Ÿ��ŭ �����
#while($row = $result->fetchArray(SQLITE3_ASSOC)){ $json_data[]=$row;
#echo json_encode($json_data);

// ��������
echo '{drwNo:'.$drwNo.',msg:"�߰�"}';

// �������
$db->close();

?>